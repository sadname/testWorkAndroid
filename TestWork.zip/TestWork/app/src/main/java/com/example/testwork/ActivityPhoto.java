package com.example.testwork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
        //Используйте статическую константу MediaStore.ACTION_IMAGE_CAPTURE для создания намерения, которое потом нужно передать методу
       // startActivityForResult(). Разместите на форме кнопку и ImageView, в который будем помещать полученный снимок.
        //Этот код запускает стандартное приложение камеры. Полученное с камеры изображение можно обработать в методе onActivityResult():

public class ActivityPhoto extends AppCompatActivity {
    // идентификатор запроса
    //private static final гарантирует, что этот экземпляр не подменится на что-то другое.
    //Удобно при работе с базами данных или каким-то ресурсом, не склонным к разделению.
    private static final int REQUEST_TAKE_PHOTO = 1;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        imageView = findViewById(R.id.imageView);
    }

    public void onClick(View view) {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try{
            startActivityForResult(takePhotoIntent, REQUEST_TAKE_PHOTO);
            //Метод startActivityForResult(Intent, int) со вторым параметром, идентифицирующим запрос позволяет возвращать результат.
            // Когда дочерняя активность закрывается, то в родительской активности срабатывает
            // метод onActivityResult(int, int, Intent), который содержит возвращённый результат, определённый в родительской активности.
        }catch (ActivityNotFoundException e){
            e.printStackTrace();
            //Это очень простой, но очень полезный инструмент для диагностики и исключения.
            // Он рассказывает вам, что произошло и где в коде это произошло.
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Дочерняя активность может произвольно возвратить назад объект Intent, содержащий любые дополнительные данные.
        // Вся эта информация в родительской активности появляется через метод обратного вызова Activity.onActivityResult(),
        // наряду с идентификатором, который она первоначально предоставила.
        //super - текущий экземпляр родительского класса.
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK) {
            // фото было сделано, извлекаем миниатюру картинки
            //Bundle необходим для временного хранения данных в процессе выполнения. Это отличный выбор при передаче данных между активностями.
            Bundle extras = data.getExtras();

            Bitmap thumbnailBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(thumbnailBitmap);
        }
        //По умолчанию фотография возвращается в виде объекта Bitmap, содержащего миниатюру.
        // Этот объект находится в параметре data, передаваемом в метод onActivityResult(). Чтобы получить миниатюру в виде объекта Bitmap,
        // нужно вызвать метод getParcelableExtra() из намерения, передав ему строковое значение data. В примере использовался упрощённый вариант.
    }
}