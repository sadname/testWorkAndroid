package com.example.testwork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;

public class main extends AppCompatActivity {

    TextView textView;
    MediaRecorder mediaRecorder;

    public static  String fileName = "recorded.3gp";
    String file = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + fileName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dictofon);


        textView = findViewById(R.id.textView);
        //Класс android.media.MediaRecorder позволяет делать записи записи медиафрагментов, включая аудио и видео.
        // MediaRecorder действует как конечный автомат. Вы задаёте различные параметры, такие как устройство-источник и формат.
        // После установки запись может выполняться как угодно долго, пока не будет остановлена.
        mediaRecorder = new MediaRecorder();

        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);

        mediaRecorder.setOutputFile(file);
    }
    public void onClick(View v){
        if(v.getId()==R.id.btnRecord){
            //Запись звука
            record();

        }
        else if (v.getId()==R.id.btnStop){
            //Остановить запись
            stopAudio();

        }
        else if (v.getId()==R.id.btnPlay){
            // Прослушать
            play();

        }
    }

    private void record() {
        // Try содержит набор операторов, в которых может возникнуть исключение.
        // За этим блоком всегда следует блок catch, который обрабатывает возникающее исключение.
        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
        textView.setText("Запись Аудио....");
    }
    private void stopAudio() {
        mediaRecorder.stop();
        mediaRecorder.release();
        textView.setText("Запись остановлена");
    }

    private void play() {
        MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(file);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
        textView.setText("Проигрывание записи");

    }
}
